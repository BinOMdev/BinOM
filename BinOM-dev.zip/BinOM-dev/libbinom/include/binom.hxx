#ifndef BINOM_HXX
#define BINOM_HXX

#include "variables/number.hxx"
#include "variables/bit_array.hxx"
#include "variables/buffer_array.hxx"
#include "variables/array.hxx"
#include "variables/list.hxx"
#include "variables/map.hxx"
#include "variables/multi_map.hxx"

#endif // BINOM_HXX
