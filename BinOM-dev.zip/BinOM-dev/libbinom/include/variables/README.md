# BinOM Variable

Public interface that allows you to interact with BinOM data structures
